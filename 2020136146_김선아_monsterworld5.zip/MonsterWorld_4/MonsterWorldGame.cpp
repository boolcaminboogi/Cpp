﻿#include "MonsterWorld.h"
#include "VariousMonster.h"
#include "Human.h"
#include "Canvas.h"
#include <time.h>

void main()
{
	srand((unsigned int)time(NULL));
	int w = 16, h = 8;

	MonsterWorld game(w, h);

	game.add(new Zombie("허접한좀비", "§", rand() % w, rand() % h));
	game.add(new Vampire("뱀파이어짱", "†", rand() % w, rand() % h));
	game.add(new Smombi("스몸비", "/", rand() % w, rand() % h));
	game.add(new KChost("어쩌다귀신", "＠", rand() % w, rand() % h));
//	game.add(new Jiangshi("못먹어도고", "↔", rand() % w, rand() % h, true));
//	game.add(new Jiangshi("못먹어도세로", "↕", rand() % w, rand() % h, false));
	game.add(new Anyang("안양검은발", "♣", rand() % w, rand() % h));
	//game.add(new Siangshi("수퍼강시", "◀", rand() % w, rand() % h));
	game.add(new Tuman1("미래의인류1", "우", rand() % xMax, rand() % yMax));
	game.add(new Tuman2("미래의인류2", "좌", rand() % xMax, rand() % yMax));
	
	game.play(500, 100);		// 최대 500번 반복, 반복마다 10msec 기다리도록 함
	printf("--------게임종료------------------------\n");
}