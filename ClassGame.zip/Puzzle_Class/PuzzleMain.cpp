#include "RankingManage.h"
#inlcude "Puzzle.h"

int main()
{
	Puzzle game;
	game.play("ranking.txt");
	return 0;
}