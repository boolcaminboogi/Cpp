#include <cstdio>
#include <cstdlib>
#include <ctime>


class SpeedGuguGame {
	int NumGames = 0;
	int NumWins = 0;
	double Score = 0;
	
	bool playGuguOnce() {
		int a = rand() % 9 + 1;
		int b = rand() % 9 + 1;
		int result;

		NumGames++;
		printf("[����%2d��] %2d x %2d = ", NumGames, a, b);
		scanf_s("%d", &result);
		if (result == a * b)
			NumWins++;
		return(result == a * b);
	}

public:
	double tElapsed = 0;				//�ɸ� �ð�
	double play(int nPlay) {
		clock_t t0 = clock();
		for (int i = 0; i < nPlay; i++)
		{
			if (playGuguOnce() == false)
				printf("����\n");
			else
				printf("����\n");
		}
		clock_t t1 = clock();
		tElapsed = (double)(t1 - t0) / CLOCKS_PER_SEC;
		Score = (NumWins) ? 10.0 * NumWins : 0.0;
		return Score;
	}
};