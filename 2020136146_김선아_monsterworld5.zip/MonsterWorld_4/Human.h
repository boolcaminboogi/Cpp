﻿#pragma once
#include "Monster.h"
#include "Canvas.h"
#include <conio.h>
#pragma warning(disable:4996)

enum Direction { Left = 75, Right = 77, Up = 72, Down = 80 };

class Human : public Monster {
public:
	Human(string n = "미래인류", string i = "human", int px = 0, int py = 0)
		: Monster(n, i, px, py) {}
	~Human() { cout << "[Human ]"; }

	int getDirKey() { return getchar() == 224 ? getchar() : 0; }
	void move(int** map, int maxx, int maxy) {
		if (kbhit()) {
			char ch = getDirKey();
			if (ch == Left)x--;
			else if (ch == Right)x++;
			else if (ch == Up)y--;
			else if (ch == Down)y++;
			else return;
			clip(maxx, maxy);
			eat(map);
		}
	}
};

class Tuman1 : public Human {
public:
	Tuman1(string n = "미래인류", string i = "우", int px = 0, int py = 0)
		: Human(n, i, px, py) {}
	~Tuman1() { cout << "[Tuman1 ]"; }

	void moveHuman(int** map, int maxx, int maxy) {
		//if (kbhit()) { // 1. 키보드 입력이 감지되면
			int pressedKey = getch(); // 2. 아스키 코드 값을 가져오고
			switch (pressedKey) { // 3. 입력받은 키에 해당하는 동작을 수행한다.
			case 72:
				y++;
				break;
				// 위로 이동
			case 80:
				y--;
				break;
				// 아래로 이동
			case 75:
				x--;
				break;
				// 왼쪽으로 이동
			case 77:
				x++;
				break;
				// 오른쪽으로 이동
			}
			clip(maxx, maxy);
			eat(map);
		//}
	}
};

class Tuman2 : public Human {
public:
	Tuman2(string n = "미래인류", string i = "좌", int px = 0, int py = 0)
		: Human(n, i, px, py) {}
	~Tuman2() { cout << "[Tuman2 ]"; }
	/*void move() {
		clip(maxx, maxy);
		eat(map);
	}*/
};