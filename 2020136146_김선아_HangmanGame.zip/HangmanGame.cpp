#include "Hangman.h"

void main()
{
	Hangman game;
	game.play("galaxy");
}